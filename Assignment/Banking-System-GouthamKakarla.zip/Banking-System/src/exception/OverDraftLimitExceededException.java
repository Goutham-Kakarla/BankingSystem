package exception;

public class OverDraftLimitExceededException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OverDraftLimitExceededException(String message)
	{
		super();
	}
}
